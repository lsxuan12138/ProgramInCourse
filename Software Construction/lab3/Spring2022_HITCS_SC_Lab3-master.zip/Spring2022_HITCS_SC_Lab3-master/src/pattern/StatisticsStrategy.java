package pattern;

public interface StatisticsStrategy {
	// TODO

}
