package pattern;

public interface SelectionStrategy {

	// TODO

}
