package poll;

import auxiliary.Person;

public class Election extends GeneralPollImpl<Person> implements Poll<Person> {

	//TODO
}
