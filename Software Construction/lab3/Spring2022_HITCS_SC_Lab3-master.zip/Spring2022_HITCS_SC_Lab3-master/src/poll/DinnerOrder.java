package poll;

import auxiliary.Dish;

public class DinnerOrder extends GeneralPollImpl<Dish> implements Poll<Dish> {
	//TODO
}
