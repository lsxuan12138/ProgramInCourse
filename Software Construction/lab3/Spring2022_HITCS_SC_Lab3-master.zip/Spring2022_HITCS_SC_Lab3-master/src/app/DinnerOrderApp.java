package app;

public class DinnerOrderApp {
	
	public static void main(String[] args) throws Exception {
		// TODO
	}
}
