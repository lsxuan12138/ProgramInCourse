package vote;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class VoteItemTest {

	// test strategy
	// TODO
	
	@Test
	void test() {
		fail("Not yet implemented");
	}

}
